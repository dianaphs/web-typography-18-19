// Hier kan je tijden toevoegen in secondes
// Op die mommenten komt er een class op de body.
sounds = [
	0,
	9,
	12,
	15,
	16.5,
    17,
	24,
	25.8,
    26,
	31,
	32,
    32.5,
	75,
    87,
    131
];